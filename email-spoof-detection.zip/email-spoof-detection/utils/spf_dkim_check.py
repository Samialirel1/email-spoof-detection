import re

def extract_domain(email_address: str):
    match = re.search(r'@([a-zA-Z0-9.-]+)', email_address or '')
    return match.group(1).lower() if match else None

def check_spf_dkim(parsed_header: dict) -> str:
    received = parsed_header.get('Received', '')
    from_address = parsed_header.get('From', '')
    return_path = parsed_header.get('Return-Path', '')
    spf_result = parsed_header.get('Received-SPF', '')
    auth_results = parsed_header.get('Authentication-Results', '')

    issues = []

    from_domain = extract_domain(from_address)
    return_domain = extract_domain(return_path)

    # Detect mismatch
    if from_domain and return_domain and from_domain != return_domain:
        issues.append(f"Domain mismatch: From ({from_domain}) ≠ Return-Path ({return_domain})")

    # Authentication fails
    if 'spf=fail' in spf_result.lower() or 'spf=fail' in received.lower():
        issues.append("SPF check failed ")
    if 'dkim=fail' in auth_results.lower():
        issues.append("DKIM check failed ")
    if 'dmarc=fail' in auth_results.lower():
        issues.append("DMARC check failed ")

    # Final verdicts
    if issues:
        return '❌ Spoofing Detected:\n' + '\n'.join(issues)

    if 'spf=pass' in spf_result.lower() or 'spf=pass' in received.lower() or \
       'dkim=pass' in auth_results.lower() or 'dmarc=pass' in auth_results.lower():
        return '✅ Legitimate: not spoofed email'

    return '⚠️ Inconclusive: Not verified results, but no spoofing signs found.'
