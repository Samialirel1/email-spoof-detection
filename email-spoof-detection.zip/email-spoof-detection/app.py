
from flask import Flask, render_template, request
from utils.header_parser import parse_email_header
from utils.spf_dkim_check import check_spf_dkim
import email
from email import policy

app = Flask(__name__)

def extract_headers_from_eml(eml_file):
    from email import policy
    from email.parser import BytesParser

    msg = BytesParser(policy=policy.default).parse(eml_file)
    headers = {}

    # Extract important headers directly
    for key, val in msg.items():
        headers[key.strip()] = val.strip()

    # Parse raw text to catch folded headers like Authentication-Results
    raw_lines = str(msg).splitlines()
    for line in raw_lines:
        line_lower = line.lower()
        if line_lower.startswith("authentication-results"):
            headers["Authentication-Results"] = line
        elif line_lower.startswith("received-spf"):
            headers["Received-SPF"] = line
        elif line_lower.startswith("return-path"):
            headers["Return-Path"] = line.split(":", 1)[1].strip()
        elif line_lower.startswith("from:"):
            headers["From"] = line.split(":", 1)[1].strip()
        elif line_lower.startswith("received:") and "Received" not in headers:
            headers["Received"] = line

    return headers

@app.route('/', methods=['GET', 'POST'])
def index():
    result = None
    if request.method == 'POST':
        parsed_info = {}

        # Prefer .eml upload if provided
        if 'emlfile' in request.files and request.files['emlfile'].filename:
            eml_file = request.files['emlfile']
            parsed_info = extract_headers_from_eml(eml_file)
        elif request.form.get('header'):
            header_text = request.form['header']
            parsed_info = parse_email_header(header_text)

        if parsed_info:
            result = check_spf_dkim(parsed_info)
        else:
            result = "No header data provided."

    return render_template('index.html', result=result)

if __name__ == '__main__':
    # Set debug=False in production
    app.run(debug=True)
