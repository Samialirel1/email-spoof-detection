# utils/header_parser.py

def parse_email_header(header_text: str) -> dict:
    parsed = {}
    current_key = None

    for line in header_text.splitlines():
        if not line.strip():
            continue
        if ':' in line:
            key, val = line.split(':', 1)
            parsed[key.strip()] = val.strip()
            current_key = key.strip()
        elif current_key:
            parsed[current_key] += ' ' + line.strip()

    return parsed